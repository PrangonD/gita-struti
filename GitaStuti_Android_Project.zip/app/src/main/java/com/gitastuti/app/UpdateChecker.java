package com.gitastuti.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import org.json.JSONObject;

public class UpdateChecker {

    public static class Info {
        public long code;
        public String name;
        public String url;
        public String notes;
    }

    public static long currentCode(Context ctx) {
        try {
            PackageInfo p = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String currentName(Context ctx) {
        try {
            return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Returns newer release info, or null if up to date. Throws on network error. Call off the main thread. */
    public static Info check(Context ctx) throws Exception {
        // Redirect method: no API rate limit (GitHub API blocks many phones on shared IPs)
        java.net.HttpURLConnection c = (java.net.HttpURLConnection)
            new java.net.URL("https://github.com/" + Config.OWNER + "/" + Config.REPO + "/releases/latest").openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "GitaStuti-App");
        String loc;
        int rc;
        try {
            rc = c.getResponseCode();
            loc = c.getHeaderField("Location");
        } finally {
            c.disconnect();
        }
        if (loc == null || !loc.contains("/tag/")) throw new Exception("কোনো রিলিজ পাওয়া যায়নি (HTTP " + rc + ")");
        String tag = loc.substring(loc.lastIndexOf('/') + 1);
        long code = Long.parseLong(tag.replaceAll("[^0-9]", ""));
        if (code <= currentCode(ctx)) return null;

        Info r = new Info();
        r.code = code;
        r.name = tag;
        r.url = "https://github.com/" + Config.OWNER + "/" + Config.REPO + "/releases/download/" + tag + "/GitaStuti.apk";
        r.notes = "";
        try { // release notes are optional
            r.notes = new JSONObject(Net.get(Config.RELEASE_API)).optString("body", "").trim();
        } catch (Exception ignored) { }
        return r;
    }
}
