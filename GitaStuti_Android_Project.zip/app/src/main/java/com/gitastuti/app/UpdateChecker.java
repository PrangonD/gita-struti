package com.gitastuti.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

public class UpdateChecker {

    public static class Info {
        public long code;
        public String name;
        public String url;
        public String notes;
    }

    public static long currentCode(Context ctx) {
        try {
            PackageInfo p = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String currentName(Context ctx) {
        try {
            return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Returns newer release info, or null if up to date. Throws on network error. Call off the main thread. */
    public static Info check(Context ctx) throws Exception {
        JSONObject o = new JSONObject(Net.get(Config.RELEASE_API));
        String tag = o.optString("tag_name", "");
        long code = Long.parseLong(tag.replaceAll("[^0-9]", ""));
        if (code <= currentCode(ctx)) return null;
        String apk = null;
        JSONArray a = o.optJSONArray("assets");
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                String u = a.getJSONObject(i).optString("browser_download_url", "");
                if (u.endsWith(".apk")) { apk = u; break; }
            }
        }
        if (apk == null) apk = o.optString("html_url");
        Info r = new Info();
        r.code = code;
        r.name = o.optString("name", tag);
        r.url = apk;
        r.notes = o.optString("body", "").trim();
        return r;
    }
}
