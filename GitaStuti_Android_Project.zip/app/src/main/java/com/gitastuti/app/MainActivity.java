package com.gitastuti.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.Locale;

public class MainActivity extends Activity {

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String ttsErr = null;
    private String pendingText = null;
    private int pendingTok = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#FFFAF0"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(WebSettings.FORCE_DARK_OFF);
        }

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("file:///android_asset/");
            }
        });

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5);
        }
        Notifier.channels(this);
        Notifier.schedule(this);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html" + hashFrom(getIntent()));
        }

        initTts();
        backgroundChecks();
    }

    private String hashFrom(Intent i) {
        String h = i == null ? null : i.getStringExtra("hash");
        return h == null ? "" : h;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String h = hashFrom(intent);
        if (!h.isEmpty()) web.loadUrl("file:///android_asset/index.html" + h);
    }

    // ---------- TTS ----------
    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsErr = "ফোনে Text-to-speech ইঞ্জিন পাওয়া যায়নি। Google Text-to-speech অ্যাপ ইনস্টল করুন।";
            } else {
                Locale[] tries = {new Locale("bn", "IN"), new Locale("bn", "BD"), new Locale("bn")};
                boolean ok = false;
                for (Locale l : tries) {
                    int r = tts.setLanguage(l);
                    if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) { ok = true; break; }
                }
                if (!ok) ttsErr = "বাংলা ভয়েস নেই। ফোনের Settings → Text-to-speech → Google → ভাষা → বাংলা ডাউনলোড করুন।";
                tts.setSpeechRate(0.85f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { js("window.onTtsDone&&onTtsDone(" + id + ")"); }
                    @Override public void onError(String id) { js("window.onTtsError&&onTtsError()"); }
                });
            }
            ttsReady = true;
            if (pendingText != null) { String t = pendingText; pendingText = null; doSpeak(t, pendingTok); }
        });
    }

    private void doSpeak(String text, int tok) {
        if (ttsErr != null) { js("window.onTtsError&&onTtsError(" + JSONObject.quote(ttsErr) + ")"); return; }
        android.os.Bundle p = new android.os.Bundle();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, p, String.valueOf(tok));
    }

    private void js(final String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    // ---------- update + content checks ----------
    private void backgroundChecks() {
        new Thread(() -> {
            String c = ContentStore.refresh(this);
            if (c != null) js("window.onContentUpdated&&onContentUpdated(" + JSONObject.quote(c) + ")");
            try {
                final UpdateChecker.Info u = UpdateChecker.check(this);
                if (u != null && Notifier.prefs(this).getLong("prompted", 0) < u.code) {
                    Notifier.prefs(this).edit().putLong("prompted", u.code).apply();
                    runOnUiThread(() -> showUpdateDialog(u));
                }
            } catch (Exception ignored) { }
        }).start();
    }

    private void showUpdateDialog(final UpdateChecker.Info u) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
            .setTitle("নতুন আপডেট এসেছে")
            .setMessage(u.notes.isEmpty() ? "অ্যাপের নতুন সংস্করণ পাওয়া গেছে।" : u.notes)
            .setPositiveButton("আপডেট করুন", (d, w) -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u.url))))
            .setNegativeButton("পরে", null)
            .show();
    }

    // ---------- JS bridge ----------
    private class Bridge {
        @JavascriptInterface public void speak(String text, int tok) {
            runOnUiThread(() -> {
                if (!ttsReady) { pendingText = text; pendingTok = tok; return; }
                doSpeak(text, tok);
            });
        }
        @JavascriptInterface public void stopSpeak() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }
        @JavascriptInterface public String getCachedContent() {
            String c = ContentStore.cached(MainActivity.this);
            return c == null ? "" : c;
        }
        @JavascriptInterface public String getSettings() {
            try {
                JSONObject o = new JSONObject();
                o.put("on", Notifier.dailyOn(MainActivity.this));
                o.put("h", Notifier.hour(MainActivity.this));
                o.put("m", Notifier.minute(MainActivity.this));
                o.put("ver", UpdateChecker.currentName(MainActivity.this));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public void setDaily(boolean on, int h, int m) {
            Notifier.prefs(MainActivity.this).edit()
                .putBoolean("daily_on", on).putInt("hour", h).putInt("min", m).apply();
            Notifier.schedule(MainActivity.this);
        }
        @JavascriptInterface public void testNotif() {
            new Thread(() -> Notifier.showDailyVerse(MainActivity.this)).start();
        }
        @JavascriptInterface public void checkUpdate() {
            new Thread(() -> {
                try {
                    final UpdateChecker.Info u = UpdateChecker.check(MainActivity.this);
                    if (u == null) js("window.onUpdateResult&&onUpdateResult('অ্যাপ সর্বশেষ সংস্করণে আছে')");
                    else runOnUiThread(() -> showUpdateDialog(u));
                } catch (Exception e) {
                    js("window.onUpdateResult&&onUpdateResult('আপডেট খোঁজা যায়নি। ইন্টারনেট দেখুন।')");
                }
            }).start();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
