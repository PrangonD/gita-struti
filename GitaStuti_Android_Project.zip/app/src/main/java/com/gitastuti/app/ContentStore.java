package com.gitastuti.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Reads bundled content.json, or the newer downloaded copy. */
public class ContentStore {

    public static class Verse {
        public int cat, sec;
        public String text, meaning, title;
    }

    private static File cacheFile(Context c) { return new File(c.getFilesDir(), "content.json"); }

    private static String readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    /** Downloaded copy if present, else null. */
    public static String cached(Context c) {
        try {
            File f = cacheFile(c);
            if (f.exists()) return readStream(new java.io.FileInputStream(f));
        } catch (Exception ignored) { }
        return null;
    }

    public static String load(Context c) {
        String s = cached(c);
        if (s != null) return s;
        try { return readStream(c.getAssets().open("content.json")); }
        catch (Exception e) { return null; }
    }

    /** Download content.json; returns the new JSON if it is newer, else null. */
    public static String refresh(Context c) {
        try {
            String s = Net.get(Config.CONTENT_URL);
            JSONObject o = new JSONObject(s);
            int rev = o.optInt("rev", 0);
            if (o.optJSONObject("D") == null) return null;
            SharedPreferences p = c.getSharedPreferences("gs", Context.MODE_PRIVATE);
            if (rev <= p.getInt("rev", 1)) return null;
            FileOutputStream f = new FileOutputStream(cacheFile(c));
            f.write(s.getBytes("UTF-8"));
            f.close();
            p.edit().putInt("rev", rev).apply();
            return s;
        } catch (Exception e) {
            return null;
        }
    }

    private static String stripTags(String s) {
        return s.replaceAll("<span[^>]*>.*?</span>", "").replaceAll("<[^>]*>", "").trim();
    }

    public static List<Verse> verses(Context c) {
        List<Verse> out = new ArrayList<>();
        try {
            JSONArray cats = new JSONObject(load(c)).getJSONObject("D").getJSONArray("cats");
            for (int i = 0; i < cats.length(); i++) {
                JSONObject cat = cats.getJSONObject(i);
                JSONArray secs = cat.getJSONArray("secs");
                for (int j = 0; j < secs.length(); j++) {
                    JSONArray b = secs.getJSONObject(j).getJSONArray("b");
                    for (int k = 0; k < b.length(); k++) {
                        JSONObject x = b.getJSONObject(k);
                        if (!"v".equals(x.optString("k"))) continue;
                        JSONArray l = x.getJSONArray("l");
                        StringBuilder sb = new StringBuilder();
                        for (int m = 0; m < l.length(); m++) {
                            if (m > 0) sb.append('\n');
                            sb.append(stripTags(l.getString(m)));
                        }
                        String text = sb.toString();
                        if (text.length() < 25) continue;
                        Verse v = new Verse();
                        v.cat = i;
                        v.sec = j;
                        v.text = text;
                        v.title = cat.optString("t");
                        if (k + 1 < b.length() && "t".equals(b.getJSONObject(k + 1).optString("k")))
                            v.meaning = stripTags(b.getJSONObject(k + 1).optString("t"));
                        out.add(v);
                    }
                }
            }
        } catch (Exception ignored) { }
        return out;
    }
}
