package com.gitastuti.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DailyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context ctx, Intent intent) {
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                String a = intent == null ? null : intent.getAction();
                boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(a);
                if (!boot) {
                    Notifier.showDailyVerse(ctx);
                    try {
                        ContentStore.refresh(ctx);
                        UpdateChecker.Info u = UpdateChecker.check(ctx);
                        if (u != null && Notifier.prefs(ctx).getLong("notified", 0) < u.code) {
                            Notifier.showUpdate(ctx, u);
                            Notifier.prefs(ctx).edit().putLong("notified", u.code).apply();
                        }
                    } catch (Exception ignored) { }
                }
                Notifier.schedule(ctx);
            } finally {
                pr.finish();
            }
        }).start();
    }
}
