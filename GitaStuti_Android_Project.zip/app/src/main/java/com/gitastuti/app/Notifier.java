package com.gitastuti.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

public class Notifier {
    static final String CH_DAILY = "daily";
    static final String CH_UPDATE = "update";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("gs", Context.MODE_PRIVATE); }

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE));
        nm.createNotificationChannel(new NotificationChannel(CH_DAILY, "দৈনিক শ্লোক", NotificationManager.IMPORTANCE_DEFAULT));
        nm.createNotificationChannel(new NotificationChannel(CH_UPDATE, "অ্যাপ আপডেট", NotificationManager.IMPORTANCE_DEFAULT));
    }

    @SuppressWarnings("deprecation")
    static android.app.Notification.Builder builder(Context c, String ch) {
        return Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, ch)
                                           : new android.app.Notification.Builder(c);
    }

    static int piFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    public static String showDailyVerse(Context c) {
        channels(c);
        List<ContentStore.Verse> vs = ContentStore.verses(c);
        if (vs.isEmpty()) return "শ্লোক লোড হয়নি";
        long day = System.currentTimeMillis() / 86400000L;
        ContentStore.Verse v = vs.get((int) (day % vs.size()));

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("hash", "#/c/" + v.cat + "/s/" + v.sec);
        PendingIntent pi = PendingIntent.getActivity(c, 1, open, piFlags());

        String body = v.text + (v.meaning != null ? "\n\n" + v.meaning : "");
        android.app.Notification n = builder(c, CH_DAILY)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("আজকের শ্লোক · " + v.title)
            .setContentText(v.text.replace('\n', ' '))
            .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build();
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(1001, n);
        return null;
    }

    public static void showUpdate(Context c, UpdateChecker.Info u) {
        channels(c);
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u.url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, 2, i, piFlags());
        String txt = "নতুন সংস্করণ এসেছে। ট্যাপ করে ডাউনলোড ও ইনস্টল করুন।"
                + (u.notes.isEmpty() ? "" : "\n\n" + u.notes);
        android.app.Notification n = builder(c, CH_UPDATE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("গীতা ও স্তুতি · আপডেট")
            .setContentText("নতুন সংস্করণ এসেছে, ট্যাপ করে আপডেট করুন")
            .setStyle(new android.app.Notification.BigTextStyle().bigText(txt))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build();
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(1002, n);
    }

    // ---- scheduling ----
    public static boolean dailyOn(Context c) { return prefs(c).getBoolean("daily_on", true); }
    public static int hour(Context c) { return prefs(c).getInt("hour", 7); }
    public static int minute(Context c) { return prefs(c).getInt("min", 0); }

    public static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, DailyReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 10, i, piFlags());
        am.cancel(pi);
        if (!dailyOn(c)) return;
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, hour(c));
        t.set(Calendar.MINUTE, minute(c));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 30000) t.add(Calendar.DAY_OF_YEAR, 1);
        if (Build.VERSION.SDK_INT >= 23)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi);
        else
            am.set(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi);
    }
}
