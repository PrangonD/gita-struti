package com.gitastuti.app;

/** GitHub repo settings. Change here if repo name changes. */
public class Config {
    public static final String OWNER = "PrangonD";
    public static final String REPO = "gita-struti";
    public static final String RELEASE_API =
        "https://api.github.com/repos/" + OWNER + "/" + REPO + "/releases/latest";
    public static final String CONTENT_URL =
        "https://raw.githubusercontent.com/" + OWNER + "/" + REPO + "/main/content.json";
}
